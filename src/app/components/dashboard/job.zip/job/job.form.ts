import { Component, Input, Output, EventEmitter } from '@angular/core';
import { Validators, FormGroup, FormControl } from '@angular/forms';
import { JobDemandModel } from './job.model';

@Component({
    selector: 'kendo-grid-edit-form',
    styles: [
    "input[type=text] { width: 100%; } .form-group.text_bx.col-md-12 {width: 96%;}"
    ],

    templateUrl: './job.form.html',
})
export class GridEditFormComponent {
    public editForm = new FormGroup({
        'vesselName': new FormControl(),
        'height': new FormControl(),
        'draft': new FormControl(),
        'srd': new FormControl(),
        'cst': new FormControl(),
        'orderNo': new FormControl(),
        'jobType': new FormControl(),
        'locationFromCode': new FormControl(),
        'locationToCode': new FormControl(),
        'status': new FormControl(),
        'pilotLicense': new FormControl(),
        'deployedDtae': new FormControl(),
        'arrivedTime': new FormControl(),
        'onboardTime': new FormControl(),
        'remarksText': new FormControl(),
        'vesselId': new FormControl(),
        'vesselTypeCode': new FormControl(),
        'pilotCode': new FormControl(),
        'mmsi': new FormControl(),
        'startTime': new FormControl(),
        'endTime': new FormControl(),
        'agentContactDetails': new FormControl(),
        'plannedEndTime': new FormControl(),
        'plannedStartTime': new FormControl(),
        'effectiveCST': new FormControl(),
        'priorityCategoryName': new FormControl(),
        'customerName': new FormControl(),
        'grossTonnage': new FormControl(),
        'srtDateFormate':new FormControl(), 
        'cstDateFormate': new FormControl(),
        'effectiveCSTFormate': new FormControl(),
        'plannedStartTimeFormate': new FormControl(),
        'plannedEndTimeFormate': new FormControl(),
        'deployedTimeFormate': new FormControl(),
        'arrivedTimeFormate': new FormControl(),
        'onboardTimeFormate': new FormControl(),
        'startTimeFormate': new FormControl(),
        'endTimeFormate': new FormControl(),
        'contDetail': new FormControl()
    });

    public active: boolean = false;
    @Input() public isNew: boolean = false;

    @Input() public set model(jobDemandModel: JobDemandModel) {
        this.editForm.reset(jobDemandModel);

        this.active = jobDemandModel !== undefined;
    }

    @Output() cancel: EventEmitter<any> = new EventEmitter();
    @Output() save: EventEmitter<JobDemandModel> = new EventEmitter();

    public onSave(e): void {
        e.preventDefault();
        this.save.emit(this.editForm.value);
        this.active = false;
    }

    public onCancel(e): void {
        e.preventDefault();
        this.closeForm();
    }

    public closeForm(): void {
        this.active = false;
        this.cancel.emit();
    }
}