export class JobDemandModel {
    public vesselName: any;
    public height: any;
    public draft: any;
    public srd: any;
    public cst: any;
    public locationFromCode: any;
    public locationToCode: any;
    public status: any;
    public orderNo: any;
    public jobType:  any;
	public priorityCategoryName: any;
	public effectiveCST: any;
	public plannedStartTime: any;
	public plannedEndTime: any;
	public agentContactDetails: any;
	public pilotLicense: any;
	public deployedDtae: any;
	public arrivedTime: any;
	public onboardTime: any;
	public startTime: any;
	public endTime: any;
	public remarksText: any;
	public vesselId: any;
	public vesselTypeCode: any;
	public pilotCode: any;
	public mmsi: any;
	public customerName: any;
	public grossTonnage: any;
	public srtDateFormate:any; 
	public cstDateFormate: any;
	public effectiveCSTFormate: any;
	public plannedStartTimeFormate: any;
	public plannedEndTimeFormate: any;
	public deployedTimeFormate: any;
	public arrivedTimeFormate: any;
	public onboardTimeFormate: any;
	public startTimeFormate: any;
	public endTimeFormate: any;
}
export class JobDemandFilterModel {
	public type: any;
	public name: any;
	public fromDate: any;
	public toDate: any;
}
export class ServiceLevelFilterModel {
	public type: any;
	public name: any;
	public fromDate: any;
	public toDate: any;
	public startTime: any;
	public endTime: any;
}