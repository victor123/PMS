import { Component, OnInit, Inject, OnChanges, AfterViewInit, ViewChild, ElementRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { process, State } from '@progress/kendo-data-query';
import { IntlService } from '@progress/kendo-angular-intl';
import { PilotDemandDataService } from '../../../services/pilotdemadchart.service';
import { CategoriesService } from '../../../services/northwind.service';
import { GridComponent, GridDataResult, DataStateChangeEvent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { JobDemandModel, JobDemandFilterModel } from './job.model';
import { Observable } from 'rxjs/Observable';
import * as moment from 'moment';
@Component({
  selector: 'job-grid',
  templateUrl: './job.component.html',
  styleUrls: [],
  providers: [PilotDemandDataService, CategoriesService]
})
export class JobComponent {
  view: Observable < GridDataResult > ;
  public state: State = {
    skip: 0,
    take: 5,
    filter: {
      logic: "and",
      filters: []
    }
  };
  public editDataItem: JobDemandModel;
  public jobDemandFilterModel: JobDemandFilterModel;
  public isNew: boolean;
  public defaultItem: { text: string, value: string } = { text: "Vessel", value: "Vessel" };
  public listItems: Array < { text: string, value: any } > = [{ text: "Customer", value: "Customer" }, { text: "Vessel", value: "Vessel" }, ];
  public gridDataa: any[] = [];
  public size: any[] = [5, 15, 20, 25];
  public steps: any = { hour: 2, minute: 5 };
  public filterForm: FormGroup;
  public gridData: GridDataResult;
  public gridView: GridDataResult;
  public buttonCount: number = 5;
  public info: boolean = true;
  public types: 'numeric' | 'input' = 'numeric';
  public pageSizes: boolean = true;
  public previousNext: boolean = true;
  public selectedItem = this.defaultItem;
  public notvalid: boolean = false;
  public min: Date = new Date(2017, 1, 1);
  public max: Date = new Date(2018, 1, 1);
  public min1: Date = new Date(2017, 1, 1);
  public max1: Date = new Date(2018, 1, 1);
  @ViewChild('dropdown') el: ElementRef;
  data: any[]
  constructor(public services: PilotDemandDataService, public service: CategoriesService, public fb: FormBuilder, public intl: IntlService) {
    this.view = service;
    console.log(this.view)
    this.filterForm = fb.group({
      'type': '',
      'name': '',
      'fromDate': ['', Validators.compose([Validators.required])],
      'toDate': ['', Validators.compose([Validators.required])]
    })
    this.jobDemandFilterModel = new JobDemandFilterModel();
  }
  fromDate: Date = new Date();
  toDate: Date = new Date();
  type: any ='';
  name: '';
  public pageChange({ skip, take }: PageChangeEvent): void {
    this.skip = skip;
    this.pageSize = take;
    this.loadData();
  }
  public value: Date = new Date();
  public exampleFlag = true;  
  ngOnInit() {
    this.service.query(this.state);
    this.loadGridData({
      'type': '',
      'name': '',
      'fromDate': new Date(),
      'toDate': new Date()
    });
    // this.el['value']="Select Customer/Vessel"
    let setVal = this.exampleFlag;
    this.valChange(setVal);  }
  // public today = new Date();
  // public max: Date = new Date(this.today.getFullYear(), this.today.getMonth(), this.today.getDate());
  public dataStateChange(state: DataStateChangeEvent): void {
    this.state = state;
    this.service.query(this.state);
    //this.gridData = process(this.gridDataa, this.state);
    console.log('state change in grid:', state, this.gridData)
  }
  public loadGridData(jobDemandFilterModel: JobDemandFilterModel) {
    jobDemandFilterModel.fromDate = this.formatValue(jobDemandFilterModel.fromDate);
    jobDemandFilterModel.toDate = this.formatValue(jobDemandFilterModel.toDate);
    console.log(jobDemandFilterModel);
    let value:any=jobDemandFilterModel;
    this.state.filter.filters=value;
    this.service.query(this.state);
    //this.state.filter.filters=value
    // this.services.jobtableData(jobDemandFilterModel).subscribe((res) => {
    //   this.gridDataa = res;
    //   this.gridData = process(res, this.state);
    //   this.loadData();
    // })
  }
  public editHandler({ dataItem }) {

    let contDetail = dataItem.customerAgentName;
    if ((dataItem.agentContactDetails != null) && (contDetail != null)) {
      dataItem['contDetail'] = contDetail +' / '+ dataItem.agentContactDetails;
    } else if (contDetail != null) {
      dataItem['contDetail'] = contDetail+' / '+ '';
    } else if(dataItem.agentContactDetails != null){
      dataItem['contDetail'] = ''+' / '+ dataItem.agentContactDetails;
    }  else{
      dataItem['contDetail'] = ''+' / '+'';
    }
    
    this.editDataItem = dataItem;
    this.isNew = false;

  }
  public cancelHandler() {
    this.editDataItem = undefined;
  }
  public saveHandler() {
    //this.editDataItem = undefined;
  }
  valChange(value) {
    let control = this.filterForm.get('name');
    // control.disable();
    if (value == 1) {
      control.disable();
    } else if (value == 2) {
      control.enable()
    }
  }
  public onFilter(value: any) {
    console.log(value)
    if (value.type === "vessel" || value.type === "customer") {
      console.log(value.type)
      if (value.name === undefined || value.name === "") {
        console.log(value.name)
        this.notvalid = true
        return;
      } else this.notvalid = false;
    } else this.notvalid = false;
    value.fromDate = this.formatValue(value.fromDate);
    value.toDate = this.formatValue(value.toDate);
    this.state.skip=0;
    this.state.take=5;
    this.state.sort = [];
    this.state.filter.filters=value
    this.service.query(this.state);
    //this.gridData = process(this.gridDataa, this.state)
   
  } 
  public formatTime(value ? : Date): string {
    return value ? `${this.intl.formatDate(value, 'HH:mm')}` : '';
  }
  public formatValue(value ? : Date): string {
    return value ? `${this.intl.formatDate(value, 'dd-MM-yyyy')}` : '';
  }
  public pageSize: number = 5;
  public skip: number = 0;
  onReset() {
    let control = this.filterForm.get('name');
    control.disable();
    this.filterForm.reset({
      'type': '',
      'name': '',
      'fromDate': new Date(),
      'toDate': new Date()
    });
    this.filterForm.value.fromDate = this.formatValue(this.filterForm.value.fromDate);
    this.filterForm.value.toDate = this.formatValue(this.filterForm.value.toDate);
    console.log(this.filterForm.value)
    this.state.filter.filters=this.filterForm.value
    this.state.skip=0;
    this.state.take=5;
    this.state.sort = [];
    console.log('services Query::',this.state.sort);
    this.service.query(this.state);
    this.services.filterService(this.filterForm.value, (res) => {
      //this.gridData = process(res, this.state);
      //this.gridDataa = res;
    });
    console.log(this.filterForm.value)
    this.notvalid = false;
  }
  doSomething(value: any) {
    this.pageChange(value)
  }
  public products: any[] = Array(100).fill({}).map((x, idx) => ({
    "ProductID": idx,
    "ProductName": "Product" + idx,
    "Discontinued": idx % 2 === 0
  }));
  public loadData(): void {
    this.gridData = {
      data: this.gridDataa.slice(this.skip, this.skip + this.pageSize),
      total: this.gridDataa.length
    };
  }
  public startChange() {
    var startDate = this.fromDate,
      endDate = this.toDate;
    if (startDate) {
      startDate = new Date(startDate);
      startDate.setDate(startDate.getDate());
      this.min1 = startDate;
      this.max1 = new Date(startDate.getTime() + (31 * 24 * 60 * 60 * 1000));
      this.toDate = this.min1
    }
  }
}
